<?php

$conn = mysqli_connect('localhost:3306','dseuser','123','seat_booking');

?>